package org.max.demo;

public class NotTriangleException extends Exception {


}
